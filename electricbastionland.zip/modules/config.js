export const ELECTRIC_BASTIONLAND_CONFIG = {};

ELECTRIC_BASTIONLAND_CONFIG.attributes = {

    Test: "TEST!"
}